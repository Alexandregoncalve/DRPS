require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { calcularResultados } = require('./calculo');

const app = express();
app.use(cors());
app.use(express.json());

// ============================================================
// Conexão com PostgreSQL
// ============================================================
const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 5432,
  database: process.env.DB_NAME || 'drps',
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASS || '',
});

// ============================================================
// Middleware de autenticação JWT
// ============================================================
function autenticar(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ erro: 'Token não fornecido' });
  try {
    const token = auth.split(' ')[1];
    req.usuario = jwt.verify(token, process.env.JWT_SECRET || 'drps_secret_2025');
    next();
  } catch {
    res.status(401).json({ erro: 'Token inválido' });
  }
}

// ============================================================
// ROTA: Health check
// ============================================================
app.get('/api/health', (req, res) => {
  res.json({ ok: true, versao: '1.0.0' });
});

// ============================================================
// ROTA: Login psicólogo/gestor
// ============================================================
app.post('/api/login', async (req, res) => {
  const { email, senha } = req.body;
  try {
    const { rows } = await pool.query(
      'SELECT * FROM usuarios WHERE email = $1', [email]
    );
    if (!rows.length) return res.status(401).json({ erro: 'Credenciais inválidas' });
    const usuario = rows[0];
    const ok = await bcrypt.compare(senha, usuario.senha_hash);
    if (!ok) return res.status(401).json({ erro: 'Credenciais inválidas' });
    const token = jwt.sign(
      { id: usuario.id, papel: usuario.papel, empresa_id: usuario.empresa_id, nome: usuario.nome },
      process.env.JWT_SECRET || 'drps_secret_2025',
      { expiresIn: '8h' }
    );
    res.json({ token, usuario: { nome: usuario.nome, papel: usuario.papel, crp: usuario.crp } });
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// ============================================================
// ROTA: Listar empresas
// ============================================================
app.get('/api/empresas', autenticar, async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM empresas ORDER BY nome');
    res.json(rows);
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// ============================================================
// ROTA: Criar empresa
// ============================================================
app.post('/api/empresas', autenticar, async (req, res) => {
  const { nome, cnpj } = req.body;
  try {
    const { rows } = await pool.query(
      'INSERT INTO empresas (nome, cnpj) VALUES ($1, $2) RETURNING *',
      [nome, cnpj]
    );
    res.json(rows[0]);
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// ============================================================
// ROTA: Listar setores de uma empresa
// ============================================================
app.get('/api/empresas/:empresaId/setores', autenticar, async (req, res) => {
  try {
    const { rows } = await pool.query(
      'SELECT * FROM setores WHERE empresa_id = $1 ORDER BY nome',
      [req.params.empresaId]
    );
    res.json(rows);
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// ============================================================
// ROTA: Criar setor
// ============================================================
app.post('/api/setores', autenticar, async (req, res) => {
  const { empresa_id, nome, total_trabalhadores } = req.body;
  try {
    const { rows } = await pool.query(
      'INSERT INTO setores (empresa_id, nome, total_trabalhadores) VALUES ($1, $2, $3) RETURNING *',
      [empresa_id, nome, total_trabalhadores || 0]
    );
    res.json(rows[0]);
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// ============================================================
// ROTA: Criar avaliação (gera token anônimo)
// ============================================================
app.post('/api/avaliacoes', autenticar, async (req, res) => {
  const { setor_id, data_fim } = req.body;
  try {
    const { rows } = await pool.query(
      `INSERT INTO avaliacoes (setor_id, psicologo_id, data_fim)
       VALUES ($1, $2, $3) RETURNING *`,
      [setor_id, req.usuario.id, data_fim || null]
    );
    const avaliacao = rows[0];
    const link = `${process.env.FRONTEND_URL || 'http://localhost:5173'}/responder/${avaliacao.token_anonimo}`;
    res.json({ ...avaliacao, link_anonimo: link });
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// ============================================================
// ROTA: Listar avaliações do psicólogo
// ============================================================
app.get('/api/avaliacoes', autenticar, async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT a.*, s.nome as setor_nome, e.nome as empresa_nome
       FROM avaliacoes a
       JOIN setores s ON a.setor_id = s.id
       JOIN empresas e ON s.empresa_id = e.id
       WHERE a.psicologo_id = $1
       ORDER BY a.criado_em DESC`,
      [req.usuario.id]
    );
    res.json(rows);
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// ============================================================
// ROTA PÚBLICA: Buscar avaliação pelo token (colaborador)
// ============================================================
app.get('/api/responder/:token', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT a.id, a.status, a.data_fim, s.nome as setor_nome, e.nome as empresa_nome
       FROM avaliacoes a
       JOIN setores s ON a.setor_id = s.id
       JOIN empresas e ON s.empresa_id = e.id
       WHERE a.token_anonimo = $1`,
      [req.params.token]
    );
    if (!rows.length) return res.status(404).json({ erro: 'Avaliação não encontrada' });
    if (rows[0].status === 'encerrada') return res.status(403).json({ erro: 'Avaliação encerrada' });
    res.json(rows[0]);
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// ============================================================
// ROTA PÚBLICA: Enviar respostas (colaborador anônimo)
// ============================================================
app.post('/api/responder/:token', async (req, res) => {
  const { respostas } = req.body; // [{ pergunta_num, valor_original }]
  try {
    const { rows } = await pool.query(
      'SELECT id, status FROM avaliacoes WHERE token_anonimo = $1',
      [req.params.token]
    );
    if (!rows.length) return res.status(404).json({ erro: 'Avaliação não encontrada' });
    if (rows[0].status === 'encerrada') return res.status(403).json({ erro: 'Avaliação encerrada' });

    const avaliacaoId = rows[0].id;

    // Inserir respostas em lote
    for (const r of respostas) {
      await pool.query(
        'INSERT INTO respostas (avaliacao_id, pergunta_num, valor_original) VALUES ($1, $2, $3)',
        [avaliacaoId, r.pergunta_num, r.valor_original]
      );
    }

    res.json({ ok: true, mensagem: 'Respostas registradas com sucesso!' });
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// ============================================================
// ROTA: Salvar probabilidades por tópico (psicólogo)
// ============================================================
app.post('/api/avaliacoes/:id/probabilidades', autenticar, async (req, res) => {
  const { probabilidades } = req.body; // [{ topico_num, valor }]
  try {
    for (const p of probabilidades) {
      await pool.query(
        `INSERT INTO probabilidades (avaliacao_id, topico_num, valor)
         VALUES ($1, $2, $3)
         ON CONFLICT (avaliacao_id, topico_num) DO UPDATE SET valor = $3`,
        [req.params.id, p.topico_num, p.valor]
      );
    }
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// ============================================================
// ROTA: Processar e calcular resultados
// ============================================================
app.post('/api/avaliacoes/:id/processar', autenticar, async (req, res) => {
  const id = req.params.id;
  try {
    const { rows: respostas } = await pool.query(
      'SELECT pergunta_num, valor_original FROM respostas WHERE avaliacao_id = $1',
      [id]
    );
    const { rows: probabilidades } = await pool.query(
      'SELECT topico_num, valor FROM probabilidades WHERE avaliacao_id = $1',
      [id]
    );

    const resultados = calcularResultados(respostas, probabilidades);

    // Salvar resultados
    for (const r of resultados) {
      await pool.query(
        `INSERT INTO resultados (avaliacao_id, topico_num, topico_nome, media_gravidade,
          classif_gravidade, media_probabilidade, classif_probabilidade, matriz_risco, fonte_geradora)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
         ON CONFLICT (avaliacao_id, topico_num) DO UPDATE SET
           media_gravidade=$4, classif_gravidade=$5, media_probabilidade=$6,
           classif_probabilidade=$7, matriz_risco=$8`,
        [id, r.topico_num, r.topico_nome, r.media_gravidade, r.classif_gravidade,
         r.media_probabilidade, r.classif_probabilidade, r.matriz_risco, r.fonte_geradora]
      );
    }

    await pool.query("UPDATE avaliacoes SET status='processada' WHERE id=$1", [id]);

    res.json(resultados);
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// ============================================================
// ROTA: Buscar resultados de uma avaliação
// ============================================================
app.get('/api/avaliacoes/:id/resultados', autenticar, async (req, res) => {
  try {
    const { rows } = await pool.query(
      'SELECT * FROM resultados WHERE avaliacao_id = $1 ORDER BY topico_num',
      [req.params.id]
    );
    // Contagem da matriz
    const contagem = { Baixo: 0, Médio: 0, Alto: 0, Crítico: 0 };
    rows.forEach(r => { if (contagem[r.matriz_risco] !== undefined) contagem[r.matriz_risco]++; });
    res.json({ resultados: rows, contagem });
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// ============================================================
// Iniciar servidor
// ============================================================
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`✅ DRPS Backend rodando em http://localhost:${PORT}`);
  console.log(`📋 Health check: http://localhost:${PORT}/api/health`);
});
